//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include <m8c.h>        // part specific constants and macros
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules
#include "delay.h"
#include <stdlib.h>
#include <string.h>

//The codes that will be recieved by the controller via serial
__flash char * DECLARE_NAME = "init";
__flash char * SEND_VALVECOUNT = "getvalves";
__flash char * SEND_ADDRESS = "send";
__flash char * INITIALISE = "done";
__flash char * RESET = "reset";
__flash char * SET_VALVE_POS = "setp";
__flash char * SET_VALVE_POS_ALL = "setpa";


//The codes that will be send to the valves
#define SEND_SET_VALVE_ADDR 0x2F // sets valve in AC mode (listening) to given address. arg is 0
#define SEND_SET_VALVE_POS 0x26 // give arg between 0 (fully closed) and 255 (fully open)
#define RC2 1
	
void transmit(void){
	PRT0DR |= 0x10;	
}

void stoptransmit(void){
	PRT0DR &= 0xEF;
}

void send_zero(void){ 
	//400 us onn, 400 us off
	transmit();
	Delay50uTimes(8);
	stoptransmit();
	Delay50uTimes(8);
}

void send_one(void){
	//600 us on 600 us off
	transmit();
	Delay50uTimes(12);
	stoptransmit();
	Delay50uTimes(12);
}

void transmit868byte(BYTE byte){
	int i;
	BYTE no_of_ones=0;
	
	for(i=0;i<8;i++){
		if (byte & 0x80){
			no_of_ones++;
			send_one();
			
		}
		else send_zero();
			byte=byte<<1;
	}
	
	if (no_of_ones & 0x01) //if odd parity, make even by sending one
		send_one();  
	else 
		send_zero();
}

void sendcommand(BYTE rc1, BYTE rc2, BYTE addr, BYTE cmdcode, BYTE arg){/////////
	int i;
	BYTE checksum;
	
	//Preamble (12 0s then 1)
	for(i=0;i<12;i++) 
		send_zero();
	send_one();
	
	transmit868byte(rc1);
	transmit868byte(rc2);
	transmit868byte(addr);
	transmit868byte(cmdcode);
	transmit868byte(arg);
	
	checksum=0x0C+rc1+rc2+addr+cmdcode+arg; //sum of all but preamble + 12
	transmit868byte(checksum);
	
	//send 0 at end of transmission
	send_zero();

	// delay 10ms
	for(i=0;i<200;i++)
		Delay50u(); 
}


void UART_btoa(BYTE b){
 //send a single byte decimal value (0-255) as ascii characters over the UART
//this compiles to far fewer instructions than UART_PutString(utoa()) : 61 vs 163 (approx)
	char ch;
	if (b>99){ //print hundreds
		ch=b/100+48;
		UART_PutChar(ch);
	}
	if (b>9){ //print tens
		ch=((b%100)/10)+48;
		UART_PutChar(ch);
	}
	//print ones
	ch=b%10+48;
	UART_PutChar(ch);
}



long period; // ms
unsigned long timer; // ms
BOOL send_pos=FALSE;
BYTE trigger = 0;

	
// IMPORTANT: Manually added _VC3_ISR entry to boot.tpl file
// This interrupt gets called every 1ms if SysClk is 12MHz 
// and VC3 Source is VC2 and VC1 Divider is 16 and VC2 divider is 10 and VC3 divider is 75
// Using external oscillator for good accuracy
#pragma interrupt_handler VC3_ISR
void VC3_ISR(void){	
	if(timer > 0) {
		timer--;
	} else {
		timer = period;
		if(period != 0) 
			trigger = 1; 
		PRT0DR ^= 0x40;
	  }
	
}
	
void main(void){
	int i;
	char * strPtr;
	const unsigned char * output;
	char returnString[2]; 	
	BYTE addrs[16][4];					  //Valve addresses and positions
	int valves = 0; 					  //Number of valves in use
	
	UART_CmdReset();                      // Initialize receiver/cmd buffer
	UART_IntCntl(UART_ENABLE_RX_INT);     // Enable RX interrupts   
	UART_Start(UART_PARITY_NONE);         // Enable UART
	
	period = 100000;
	timer = 100000;
	
	M8C_EnableIntMask(INT_MSK0, INT_MSK0_VC3);
	M8C_EnableGInt ;                      // Turn on interrupts
	
	UART_CPutString("\r\nPSoC RadController starting up. V2.0\r\n");
	UART_CPutString("\r\nFor each valve, put into AC mode then enter 'send'\r\n");
	UART_CPutString("When all valves have been assigned addresses, enter 'done'\r\n");
	while(1) {
		
		if(trigger) {
			trigger = 0;
			if (send_pos){
				
				for (i=0;i<valves;i++){
					sendcommand(addrs[i][0], addrs[i][1], addrs[i][2], SEND_SET_VALVE_POS, addrs[i][3]);
					UART_CPutString("Valve pos sent: ");
					UART_btoa(addrs[i][3]);
					UART_CPutString(" To valve: ");
					UART_btoa(addrs[i][0]);
					UART_CPutString("\r\n");
				}
				//pos-=3;
			}
			
		}
		
		if(UART_bCmdCheck()) { 
			// Wait for command  
			
			if(strPtr = UART_szGetParam()) {     // More than delimiter"
				if(cstrcmp(DECLARE_NAME, strPtr) == 0) {
					UART_CPutString("HomeOSValveDevice\r\n"); //Used by the HomeOS scout to find valve controllers
				}
				else if(cstrcmp(SEND_VALVECOUNT, strPtr) == 0) {
					UART_btoa(valves);						  //Used by HomeOS application to set the valves available in interface
					UART_CPutString("\r\n");
				}
				else if(cstrcmp(SEND_ADDRESS, strPtr) == 0) {
						sendcommand(valves+1, 1, valves+1, SEND_SET_VALVE_ADDR, 0x00);
						addrs[valves][0] = valves+1; 	//rc1
						addrs[valves][1] = RC2; 		//rc2
						addrs[valves][2] = valves+1; 	//addr set to the valve number
						addrs[valves][3] = 77; 			//initial pos for that valve (30%)
						
						UART_CPutString("Address sent to valve: ");
						UART_btoa(addrs[valves][0]);
						UART_PutChar(32);
						UART_btoa(addrs[valves][1]);
						UART_PutChar(32);
						UART_btoa(addrs[valves][2]);
						UART_CPutString("\r\n");	
						valves++;
				} else if(cstrcmp(INITIALISE, strPtr) == 0) {
						UART_btoa(valves);
						UART_CPutString("\r\n");
						period = 115010 + (RC2 & 0x07)*500; //start 2 minute wakeup cycle
						M8C_DisableIntMask(INT_MSK0,INT_MSK0_VC3);
						timer = period;
						M8C_EnableIntMask(INT_MSK0, INT_MSK0_VC3);
						
						send_pos = TRUE;				  //start sending positions when triggered
						for (i=0;i<valves;i++){			  //send first position packet to each valve set up (Starts their wakeup cycle)
							sendcommand(addrs[i][0], addrs[i][1], addrs[i][2], SEND_SET_VALVE_POS, addrs[i][3]);
							UART_CPutString("Valve pos sent (initial): ");
							UART_btoa(addrs[i][3]);
							UART_CPutString(" To valve: ");
							UART_btoa(addrs[i][0]);
							UART_CPutString("\r\n");
						}
				}else if(cstrcmp(RESET, strPtr) == 0) {
					send_pos = FALSE;
					valves = 0;
					UART_CPutString("Controller reset. For each valve, put into AC mode then enter 'send'\r\n");
					UART_CPutString("When all valves have been assigned addresses, enter 'done'\r\n");

				} else if(cstrcmp(SET_VALVE_POS, strPtr) == 0) {
					//record new valve position (to be sent at next wakeup)
					BYTE valveIndex = (BYTE) (atoi(UART_szGetParam())-1);
					addrs[valveIndex][3] = (BYTE) atoi(UART_szGetParam()); //set position for valve given in argument
					UART_CPutString("Valve pos recorded: ");
					UART_btoa(addrs[valveIndex][3]);
					UART_CPutString(" for valve number: ");
					UART_btoa(valveIndex+1);
					UART_CPutString("\r\n");

				} else if(cstrcmp(SET_VALVE_POS_ALL, strPtr) == 0) {
					//record new valve position for all valves(to be sent at next wakeup)
					int i;
					BYTE pos = (BYTE) atoi(UART_szGetParam());
					for (i=0;i<valves;i++){
						addrs[i][3] = pos;  //set position for each valve
					}
					UART_CPutString("Valve pos recorded: ");
					UART_btoa(pos);
					UART_CPutString(" for all valves\r\n");
					

				} else {
					UART_CPutString("\r\nNah\r\n");
				}
				
			}
			UART_CmdReset();                          // Reset command buffer 
			
		}	
	}
	UART_CPutString("***Fallen out of mainloop***\r\n");					
	
}
